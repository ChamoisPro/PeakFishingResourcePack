#ifndef TEXT_EFFECTS_26_3_FADE_GLSL
#define TEXT_EFFECTS_26_3_FADE_GLSL

// Author: nattapat2871 (https://nattapat2871.me)
void processFadeEffect(inout vec4 vertex, float speed) {
    if (speed <= 0.0) speed = 0.5;
    
    applyProjection(vertex);
    
    float alpha = sin(GameTime * 3000.0 * speed);
    alpha = (alpha + 1.0) * 0.5;
    
    vec4 texColor = get_lightmap_color();
    
    vertexColor = Color * texColor;
    vertexColor.a *= alpha; 
    
    finalize();
}

#endif // TEXT_EFFECTS_26_3_FADE_GLSL
